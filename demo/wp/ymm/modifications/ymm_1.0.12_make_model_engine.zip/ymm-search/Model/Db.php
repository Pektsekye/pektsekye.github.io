<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class Pektsekye_Ymm_Model_Db
{


    protected $_wpdb;
    protected $_mainTable;
    protected $_config;         

        
    public function __construct($config = null) {
			global $wpdb;
			
			$this->_wpdb = $wpdb;   
      $this->_mainTable = "{$wpdb->base_prefix}ymm"; 
            
      if ($config != null){
        $this->_config = $config;
      } else {   
        include_once( Pektsekye_YMM()->getPluginPath() . 'etc/config.php');		
        $this->_config = new Pektsekye_Ymm_Config();
      }             
    }    



     public function fetchColumnValues($params = array(), $categoryId = 0)     
    {
      $values = array();

      $whereProducts = '';
      if ($categoryId > 0){
        $productIds = $this->getProductIdsOfCategory($categoryId);
        if (count($productIds) > 0){        
          $whereProducts = ' AND product_id IN ('.implode(',', $productIds).')';
        }
      }
      
      $nextlevel = count($params);
            
      if ($nextlevel == 0){
        $select = "SELECT DISTINCT make FROM {$this->_mainTable} WHERE make != '' {$whereProducts} ORDER BY make";
        $values = (array) $this->_wpdb->get_col($select);
      } else if ($nextlevel == 1){
        $select = "SELECT DISTINCT model FROM {$this->_mainTable} WHERE make = '".esc_sql($params[0])."' AND model != '' {$whereProducts} ORDER BY model";
        $values = (array) $this->_wpdb->get_col($select);      
      } else {      
        $select = "SELECT DISTINCT engine FROM {$this->_mainTable} WHERE make = '".esc_sql($params[0])."' AND model = '".esc_sql($params[1])."' AND engine != '' {$whereProducts} ORDER BY engine";
        $values = (array) $this->_wpdb->get_col($select);
      }
      
      return $values;             
    }
    
    
    
     public function filterVehiclesForCategory($vehicles, $categoryId)     
    {
      $filteredVehicles = array();
      
      $productIds = $this->getProductIdsOfCategory((int)$categoryId);
      
      if (count($productIds) == 0)
        return array();
            
      foreach((array)$vehicles as $vehicle){
        $values = explode(',', $vehicle);
        if (count($values) != 3){
          continue;
        }
        $select = "SELECT make FROM {$this->_mainTable} WHERE make = '".esc_sql($values[0])."' AND model = '".esc_sql($values[1])."' AND engine = '".esc_sql($values[2])."' AND product_id IN (" . implode(',', $productIds) . ") LIMIT 1";
        $result = $this->_wpdb->get_var($select);

        if ($result){
          $filteredVehicles[] = $vehicle;    
        }   
      }
      return $filteredVehicles;             
    }
    
    
          
     public function getProductIds($values)     
    {    
      $level = count($values);
      
      if ($level == 1){
        $select = "SELECT DISTINCT product_id FROM {$this->_mainTable} WHERE make = '".esc_sql($values[0])."' OR make = ''";
      } else if ($level == 2){
        $select = "SELECT DISTINCT product_id FROM {$this->_mainTable} WHERE (make = '".esc_sql($values[0])."' or make = '') AND (model = '".esc_sql($values[1])."' or model = '')";     
      } else if ($level == 3){
        $select = "SELECT DISTINCT product_id FROM {$this->_mainTable} WHERE (make = '".esc_sql($values[0])."' or make = '') AND (model = '".esc_sql($values[1])."' or model = '') AND (engine = '".esc_sql($values[2])."' or engine = '')";
      }

      return (array) $this->_wpdb->get_col($select);    
    }



     public function searchRestrictions($query)     
    {
      $where = '';
  
      $words = preg_split("/\s+/", $query);           
      foreach ($words as $word){
        $w = "make LIKE '%".esc_sql($word)."%' OR model LIKE '%".esc_sql($word)."%'" ;  
        $where .= ($where != '' ? ' AND ' : '') . "({$w})";          
      }
  
      $select = "SELECT DISTINCT CONCAT_WS(', ', make, model, engine) as restriction  FROM {$this->_mainTable} WHERE {$where} ORDER BY make, model, engine LIMIT 64;";

      return (array) $this->_wpdb->get_col($select);         
    }
    
    
        
     public function getSampleVehicleData()     
    {
      $data = array(
        array("H4184","Daihatsu","Altis","1.6"),
        array("PPF5471","Lexus","ES300","3.0"),
        array("PPF5471","Lexus","GS300","3.0"),
        array("PPF5471","Lexus","RX300","3.0"),
        array("PPF5497","Toyota","Avalon","3.5"),
        array("PPF5497","Toyota","Caldina","1.9"),
        array("PPF5493","Toyota","Camry","2.4"),
        array("PPF5077","Toyota","Carina","1.7"),
        array("H4061","BMW","X5","4.8")      
      );
      
      $numberOfProducts = 6;
      $productIdsBySku = $this->getProductIdsBySku($numberOfProducts);
      
      if (count($productIdsBySku) == $numberOfProducts){ // if there are enough products we can use existing product SKUs for sample data
        $productSkus = array_keys($productIdsBySku);
        $data = array(
          array($productSkus[0],"Daihatsu","Altis","1.6"),
          array($productSkus[1],"Lexus","ES300","3.0"),
          array($productSkus[1],"Lexus","GS300","3.0"),
          array($productSkus[1],"Lexus","RX300","3.0"),
          array($productSkus[2],"Toyota","Avalon","3.5"),
          array($productSkus[2],"Toyota","Caldina","1.9"),
          array($productSkus[3],"Toyota","Camry","2.4"),
          array($productSkus[4],"Toyota","Carina","1.7"),
          array($productSkus[5],"BMW","X5","4.8")      
        );
      }
      
      return $data;     
    }      

      
     public function getProductRestrictions($productId)     
    {
      $productId = (int) $productId;    
         
      $select = "
        SELECT make, model, engine  
        FROM {$this->_mainTable} 
		    WHERE product_id = {$productId} 
		    ORDER BY make 	            
      ";
      
      return (array) $this->_wpdb->get_results($select, ARRAY_A);         
    }
    
    
          
     public function getProductRestrictionText($productId)     
    {          
      $text = '';
    
      $result = $this->getProductRestrictions($productId);     
      foreach ($result as $row){
        $text .= "{$row['make']}, {$row['model']}, {$row['engine']}\n";
      }
      
      return $text;     
    }
    
    
    
     public function saveProductRestrictionText($productId, $restriction)     
    {
      $productId = (int) $productId;    
         


      $data = array();
      
      $fieldNames = $this->_config->getCsvColumnNames();
      
      array_shift($fieldNames);  //we don't need the first product_id field in the restriction
          
      $numberOfFields = count($fieldNames);
      
      $lines = explode("\n", $restriction);
      foreach ($lines as $line) {
        $line = trim($line);
        
        if (empty($line))
          continue;
        
        $values = explode(',', $line);
        
        if (count($values) != $numberOfFields){
          throw new Exception();          
          return;          
        }

        $make = trim($values[0]);
        $model = trim($values[1]);
        $engine = trim($values[2]);                
                                
        $data[] = array($productId, $make, $model, $engine);         
      }
      
      $this->_wpdb->query("DELETE FROM {$this->_mainTable} WHERE product_id = {$productId}"); 
      
      if (count($data) > 0){
        $this->addValues($data);
      }                   
    }    



     public function getVehicleData($limit = 0)     
    {
      $queryLimit = $limit > 0 ? " LIMIT {$limit} " : '';    
    
      $select = "
        SELECT DISTINCT IF(LENGTH(postmeta.meta_value)>0, postmeta.meta_value, posts.ID) as product_sku, ymm.make, ymm.model, ymm.engine  
        FROM {$this->_wpdb->posts} AS posts 
		    LEFT JOIN {$this->_wpdb->postmeta} AS postmeta 
		      ON postmeta.post_id = posts.ID AND postmeta.meta_key = '_sku' 
        JOIN {$this->_mainTable} ymm 
          ON ymm.product_id = posts.ID 
		    WHERE posts.post_type = 'product'
		    ORDER BY posts.ID 
		    {$queryLimit}		            
      ";
      
      return (array) $this->_wpdb->get_results($select, ARRAY_N);     
    }              
 
 
 
     public function hasVehicleData()     
    {
      $value = $this->_wpdb->get_var("SELECT EXISTS (SELECT 1 FROM {$this->_mainTable})");
      return $value == 1;         
    }
          
      
      
    public function getProductIdsBySku($limit = 0)
    {
      $queryLimit = $limit > 0 ? " LIMIT {$limit} " : '';
      
      $select = "
        SELECT IF(LENGTH(postmeta.meta_value)>0, postmeta.meta_value, posts.ID) as product_sku, posts.ID as product_id 
        FROM {$this->_wpdb->posts} AS posts 
		    LEFT JOIN {$this->_wpdb->postmeta} AS postmeta 
		      ON postmeta.post_id = posts.ID AND postmeta.meta_key = '_sku' 
		    WHERE posts.post_type = 'product'
		    {$queryLimit}          
      ";
      $result = (array) $this->_wpdb->get_results($select, ARRAY_A);

      $productIds = array();
      foreach ($result as $row){
        $productIds[$row['product_sku']] = $row['product_id'];
      }
       
      return $productIds;   
    }      
      
      
      
    public function addValues($data)
    {         
      $valuesStr = '';    
      foreach ($data as $values){
        $cell = '';
        foreach ($values as $value)
          $cell .= ($cell != '' ? ',' : '') . "'" . esc_sql(trim($value)) . "'";
                       
        $valuesStr .= ($valuesStr != '' ? ',' : '') . "({$cell})";     
      }
      
      $this->_wpdb->query("INSERT IGNORE INTO {$this->_mainTable} (product_id, make, model, engine) VALUES {$valuesStr}");                  
    }   



    function getProductIdsOfCategory($categoryId) 
    {    
      $categoryId = (int) $categoryId;
      $select = "SELECT p.ID FROM {$this->_wpdb->posts} p
                 JOIN {$this->_wpdb->term_relationships} tr 
                  ON p.ID = tr.object_id AND p.post_type = 'product' AND p.post_status = 'publish'
                 JOIN {$this->_wpdb->term_taxonomy} tt 
                  ON  tr.term_taxonomy_id = tt.term_taxonomy_id AND tt.taxonomy = 'product_cat' 
                 WHERE tt.term_id = {$categoryId}";  
                      
      return (array) $this->_wpdb->get_col($select);    
    }



    public function emptyTable()
    {      
      $this->_wpdb->query("TRUNCATE TABLE {$this->_mainTable}"); 
    }	
       
}
