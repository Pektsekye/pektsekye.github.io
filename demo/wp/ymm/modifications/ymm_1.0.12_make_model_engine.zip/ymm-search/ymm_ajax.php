<?php

error_reporting(0);
ini_set('display_errors', 0);

if (!isset($_GET['action']) || !isset($_GET['values']))
  exit;
  
define('SHORTINIT', true);

require '../../../wp-load.php';
require_once( ABSPATH . WPINC . '/formatting.php' );
wp_plugin_directory_constants();

include_once( WP_PLUGIN_DIR . '/ymm-search/etc/config.php');		
$ymmConfig = new Pektsekye_Ymm_Config();  

include_once( WP_PLUGIN_DIR . '/ymm-search/Model/Db.php');		
$ymmDb = new Pektsekye_Ymm_Model_Db($ymmConfig);

$values = array_map('sanitize_text_field', array_map('stripslashes', (array) $_GET['values']));


if ($_GET['action'] == 'ymm_selector_fetch'){

  $categoryId = isset($_GET['cId']) ? (int) $_GET['cId'] : 0;
  
  $colValues = $ymmDb->fetchColumnValues($values, $categoryId);
  
  echo json_encode($colValues);
  exit;


} elseif ($_GET['action'] == 'ymm_selector_get_categories'){

  if (count($values) < 3){
    echo '{}'; 
    exit;     
  }
  
  require_once( ABSPATH . WPINC . '/link-template.php' );
  require_once( ABSPATH . WPINC . '/taxonomy.php' );
  require_once( ABSPATH . WPINC . '/class-wp-taxonomy.php' );
  require_once( ABSPATH . WPINC . '/rewrite.php' );
  require_once( ABSPATH . WPINC . '/class-wp-rewrite.php');
  require_once( ABSPATH . WPINC . '/class-wp-term.php' );
  require_once( ABSPATH . WPINC . '/class-wp-term-query.php' );
  require_once( ABSPATH . WPINC . '/post-formats.php' );
  require_once( ABSPATH . WPINC . '/meta.php' );
  require_once( ABSPATH . WPINC . '/class-wp-meta-query.php' );
  require_once( ABSPATH . WPINC . '/post.php' );
  require_once( ABSPATH . WPINC . '/l10n.php' );
  wp_plugin_directory_constants();

  $GLOBALS['wp_rewrite'] = new WP_Rewrite();

  $permalinks = get_option('woocommerce_permalinks', array());
  $permalinks['category_rewrite_slug']  = untrailingslashit( empty( $permalinks['category_base'] ) ? _x( 'product-category', 'slug', 'woocommerce' )   : $permalinks['category_base'] );

  register_taxonomy( 'product_cat',
    array( 'product' ) ,
    array(
      'hierarchical'          => true,
      'update_count_callback' => '_wc_term_recount',
      'show_ui'               => true,
      'query_var'             => true,
      'rewrite'          => array(
        'slug'         => $permalinks['category_rewrite_slug'],
        'with_front'   => false,
        'hierarchical' => true
      )
     )
  );

  $pIds  = $ymmDb->getProductIds($values);
  
  if (count($pIds) == 0){
    echo '{}';
    exit;     
  }
      
  $rootCategories = array();
  $categoryTree = array();       
  
  $taxonomy = 'product_cat';
  $args = array('orderby' => 'parent', 'order' => 'DESC', 'fields' => 'all');

  $productCategories = wp_get_object_terms($pIds, $taxonomy, $args);

  $childIds = array();
     
  foreach($productCategories as $category){
      $catId = $category->term_id; 

      $parentIds = get_ancestors($catId, $taxonomy);
    
      if (count($parentIds) == 0){
        $rootCategories[$catId] = 1;
      } else {
        $parentIds = array_reverse($parentIds);
        $rootCategories[$parentIds[0]] = 1;
    
        foreach ($parentIds as $i => $id) {
    
          $parentCat = get_term($id, $taxonomy);

          if (!is_wp_error($parentCat) && $parentCat) {

            if (!isset($categoryTree[$id])){
              $categoryTree[$id] = array('title' => $parentCat->name, 'children' => array());  
            }
            
            $nextInd = $i + 1;
            $childId = isset($parentIds[$nextInd]) ? $parentIds[$nextInd] : $catId;
            if (!isset($childIds[$childId])){ //no duplicates
              $categoryTree[$id]['children'][] = $childId;
              $childIds[$childId] = 1;
            }  
          }
        }
      }
  
      $categoryTree[$catId]['title'] = $category->name;
      $categoryTree[$catId]['url'] = get_term_meta($catId, 'display_type', true) != 'subcategories' ? get_term_link($category) : '';			
  }

  $rootCategories = array_keys($rootCategories);

  echo json_encode(array('rootCategoryIds'=>$rootCategories,'categories'=>$categoryTree));
  exit;  
  
  
}
