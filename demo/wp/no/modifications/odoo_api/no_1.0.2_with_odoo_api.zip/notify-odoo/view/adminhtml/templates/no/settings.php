<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$message = $this->getMessage();
$result = $this->getDebugResult();
?>
<div><h3><?php echo __('Notify Odoo Settings', 'notify-odoo'); ?></h3></div>
<?php if (isset($message['error'])): ?>
  <div id="woocommerce_errors" class="error"><p><?php echo $message['error']; ?></p></div>
<?php endif;?>
<?php if (isset($message['text'])): ?>    
  <div id="message" class="updated notice notice-success is-dismissible below-h2">
  <p><?php echo $message['text']; ?></p>    
  <button type="button" class="notice-dismiss"><span class="screen-reader-text"><?php echo __( 'Dismiss this notice.', 'woocommerce' );?></span></button></div>
<?php endif;?>
<div class="no-section">
  <hr>  
  <div><h4><?php echo __('Configuration', 'notify-odoo'); ?>:</h4></div>
  <form action="?page=notifyodoo_settings&action=updateSettings" method="post">

      <fieldset class="no-fieldset">
         <!--
          <label for="notify_url"><?php echo __('Odoo website URL', 'notify-odoo'); ?>:</label><br/>
          <input style="width:500px;" type="text" name="notify_url" id="notify_url" value="<?php echo esc_attr($this->getNotifyUrl());?>" autocomplete="off"/><br/>
          <span class="no-config-option-note"><?php echo __('It should start with http:// or https://', 'notify-odoo') ; ?></span><br/>
          <br/>    
           -->
          <input type="checkbox" name="notify_about_new_customer" id="notify_about_new_customer_field" value="1" <?php echo $this->getNotifyAboutNewCustomer() ? 'checked="checked"' : '';?>/>
          <label for="notify_about_new_customer_field"><?php echo __('Notify About New Customer', 'notify-odoo'); ?></label><br/>        
          <br/>
                           
          <input type="checkbox" name="notify_about_new_order" id="notify_about_new_order_field" value="1" <?php echo $this->getNotifyAboutNewOrder() ? 'checked="checked"' : '';?> onclick="var section = jQuery('.add-tracking-image-section'); if (this.checked){section.show()} else {section.hide();}"/>
          <label for="notify_about_new_order_field"><?php echo __('Notify About New Order', 'notify-odoo'); ?></label><br/>        
          <br/>
         <!-- 
          <div class="add-tracking-image-section" <?php echo $this->getNotifyAboutNewOrder() ? '' : 'style="display:none;"';?>>         
            <input type="checkbox" name="add_tracking_image" id="add_tracking_image_field" value="1" <?php echo $this->getAddTrackingImage() ? 'checked="checked"' : '';?>/>
            <label for="add_tracking_image_field"><?php echo __('Add Tracking Image', 'notify-odoo'); ?></label><br/>        
            <span class="no-config-option-note"><?php echo __('You can use this when server side notification does not work.', 'notify-odoo'); ?></span><br/>
            <span class="no-config-option-note"><?php echo __('It will add image tag &lt;img /&gt; on the WooCommerce\'s "Thank you for your order" page.', 'notify-odoo'); ?></span><br/>
            <span class="no-config-option-note"><?php echo __('Customer will load the image from your Odoo website so that it will get notified about the new order.', 'notify-odoo'); ?></span><br/>
            <br/>
          </div>
                             
          <label for="allow_ip_address"><?php echo __('Allow to access notifications only from IP address', 'notify-odoo'); ?>:</label><br/>
          <input type="text" class="no-allow-ip-address" name="allow_ip_address" id="allow_ip_address" value="<?php echo esc_attr($this->getAllowIpAddress());?>" autocomplete="off"/><br/>
          <span class="no-config-option-note"><?php echo sprintf(__('For debugging leave it empty so you can check the failed notifications by accesiing the static file:<br/><a href="%1$s" target="_blank">%1$s</a><br/>and then the notifications URL:<br/><a href="%2$s" target="_blank">%2$s</a><br/>in your web browser.', 'notify-odoo'), Pektsekye_NO()->getPluginUrl() . 'pub/static/new_notifications_flag.txt', admin_url('admin-ajax.php') . '?action=notifyodoo_get_notifications'); ?></span><br/>
          <span class="no-config-option-note"><?php echo sprintf(__('If you don\'t know the IP address of your Odoo website. Last time the notifications URL was accessed from Odoo server with IP %s', 'notify-odoo'), $this->getLastAccessIpAddress() != '' ? $this->getLastAccessIpAddress() : '('. __('there has been no request from Odoo server yet', 'notify-odoo') .')'); ?></span><br/>
              -->      
          <br/>                                                                                       
          <input type="submit" name="save_configuration" class="button button-primary" value="<?php echo __('Save Configuration', 'notify-odoo') ; ?>"/>
          <!--
          &nbsp;&nbsp;
          <input type="submit" name="check_connection" class="button button-primary" value="<?php echo __('Check Connection', 'notify-odoo') ; ?>"/>      
          -->
          
      </fieldset>
  </form>       
</div>     
<div class="no-section">
  <hr>
  <br/>  
  <div><h3><?php echo __('Odoo API', 'notify-odoo'); ?></h3></div>
  <br>
  <?php $ntfs = $this->getNotifications(); ?>
  <b><?php echo __('Queue'); ?>:</b>
  <form action="?page=notifyodoo_settings&action=updateSettings" method="post" onsubmit="return confirm('<?php echo esc_attr__('Are you sure you want to clear the Odoo API cron action queue ?', 'notify-odoo') ; ?>');">    
  <?php if (count($ntfs) > 0): ?>
    <table>
    <tr><td><?php echo __('Type', 'notify-odoo') ; ?></td><td style="padding-left:10px;"><?php echo __('IDs', 'notify-odoo') ; ?></td><td style="padding-left:10px;"><input type="submit" name="clear_queue" class="button button-primary" value="<?php echo __('Clear queue', 'notify-odoo') ; ?>"/></td></tr>
    <?php foreach($ntfs as $type => $ids): ?>
    <tr><td><?php echo htmlspecialchars($type); ?></td><td style="padding-left:10px;"><?php echo count($ids) > 6 ? sprintf(__('%s ... (%d total)', 'notify-odoo'), implode(', ', array_slice($ids, 0, 6)), count($ids)) : implode(', ', $ids); ?></td><td></td></tr>        
    <?php endforeach; ?>
    </table>  
    <br/>       
    <?php echo __('If cron is runnung, they will start processing in the next 1-5 minutes.', 'notify-odoo') ; ?> <br/>
  <?php else: ?>
    <i><?php echo __('There are no items to process', 'notify-odoo'); ?></i><br/>  
  <?php endif; ?>
  </form>
    
  <?php $lastProcesed = $this->getLastProcessedItems(); ?>
  <?php if (!empty($lastProcesed)): ?>
  <br/>
  <b><?php echo __('Queue history'); ?>:</b><br/>  

    <?php    
      $codes = array(
        'successful_transfer',
        'skipped',         
        'connection_error',            
        'failed_transfer'
      );    
       
      $statusNames = array(
        'successful_transfer' => __('successful transfer'),
        'skipped' => __('skipped'),         
        'connection_error' => __('connection error'),            
        'failed_transfer' => __('failed to transfer')
      );
                        
      $messages = array(      
        'successful_transfer' => 'Successful transfer.',
        'skipped' => __('Skipped. Customer with the same email or an order with the same order code already exists.'),         
        'connection_error' => __('There was a connection problem. The item will be sent later. Check the error log for more details.'),        
        'failed_transfer' => __('<font color="red">Failed to transfer.</font> Check the error log for more details.')      
      );
      
      $lastItemCode = '';   
    ?> 

    <?php if (isset($lastProcesed['last_item'])): ?>
      <?php 
        $item = $lastProcesed['last_item'];
        $code = $item['status_code'];      
        $status = __('processed');
        $message = $messages[$code];
        $lastItemCode = $code;   
      ?>      
      <?php echo sprintf(__('Last %s item: %s %s on %s. Result: %s <a href="%s" target="_blank">send again</a>', 'notify-odoo'), $status, $item['type'], $item['id'], $this->formatDateFromTimestemp($item['timestemp']), $message, $this->getSendAgainLink($item['type'], $item['id'])); ?><br/>  
    <?php endif; ?>
    
    <?php foreach($codes as $code): ?>
     
      <?php if ($code == $lastItemCode) continue; ?>
         
      <?php if (isset($lastProcesed[$code])): ?>
        
        <?php 
          $item = $lastProcesed[$code];      
          $status = $statusNames[$code];
          $message = $messages[$code];   
        ?>
                       
        <?php echo sprintf(__('Last %s item: %s %s on %s. Result: %s <a href="%s" target="_blank">send again</a>', 'notify-odoo'), $status, $item['type'], $item['id'], $this->formatDateFromTimestemp($item['timestemp']), $message, $this->getSendAgainLink($item['type'], $item['id'])); ?><br/>     
      
      <?php endif; ?>
    <?php endforeach; ?>
    <form action="?page=notifyodoo_settings&action=updateSettings" method="post">
      <input type="submit" name="clear_queue_history" class="button button-primary" value="<?php echo __('Clear queue history', 'notify-odoo') ; ?>"/>  
    </form>                   
  <?php endif; ?>
  <br> 
  <br>   
  <form action="?page=notifyodoo_settings&action=updateSettings" method="post">
    <input type="submit" name="export_customers" class="button button-primary" value="<?php echo __('Export all customers', 'notify-odoo') ; ?>"/>
    &nbsp;
    <?php echo __('start from ID: ', 'notify-odoo'); ?>
    <input style="width:60px;" type="text" name="start_from_id" value="" autocomplete="off"/><br/> 
  </form>
  <br/>  
  <form action="?page=notifyodoo_settings&action=updateSettings" method="post">
    <input type="submit" name="export_orders" class="button button-primary" value="<?php echo __('Export all orders', 'notify-odoo') ; ?>"/>
    &nbsp;
    <?php echo __('start from ID: ', 'notify-odoo'); ?>
    <input style="width:60px;" type="text" name="start_from_id" value="" autocomplete="off"/><br/> 
  </form>    
  <br>
  <br>  
  <b><?php echo __('Cron action'); ?>:</b><br/>
    <form action="?page=notifyodoo_settings&action=updateSettings" method="post">
  <?php if ($this->getIsScheduled()): ?>
    <font color="green"><?php echo __('Is scheduled', 'notify-odoo'); ?></font> &nbsp;&nbsp; <input type="submit" name="unschedule" class="button button-primary" value="<?php echo __('Unschedule', 'notify-odoo') ; ?>"/> <br/>
    <?php $timestamp = $this->getLastExecutedTimestemp();?>
    Last time the action was executed on - <i><?php echo !empty($timestamp) ? $this->formatDateFromTimestemp($timestamp) : __('unknown', 'notify-odoo'); ?></i><br/>
    <?php if (empty($timestamp) || $timestamp < (time() - 3600)): ?>
     <font color="red"> It looks like the server cron job is not set up to run the wp-cron.php script every 5 minutes!</font><br/>
    <?php endif; ?>  
  <?php else: ?>
    <font color="red"><i><?php echo __('Is not scheduled !', 'notify-odoo'); ?></i></font> &nbsp;&nbsp; <input type="submit" name="schedule" class="button button-primary" value="<?php echo __('Schedule', 'notify-odoo') ; ?>"/> <br/>  
     <?php echo __('Cron action should be scheduled to send new orders to odoo automatically.', 'notify-odoo') ; ?> <br/>
  <?php endif; ?>     
    </form>
  <br>
  <br> 
 <b><?php echo __('Connection'); ?>:</b><br/>  
  <?php $timestamp = $this->getLastSuccessfulConnection(); ?>
  <?php echo sprintf(__('Last successful connection - <i>%s</i>', 'notify-odoo'), !empty($timestamp) ? $this->formatDateFromTimestemp($timestamp) : __('unknown', 'notify-odoo')); ?> <br/>
   <br>
   <form action="?page=notifyodoo_settings&action=updateSettings" method="post" >     
    <input type="submit" name="check_odoo_api_connection" class="button button-primary" value="<?php echo __('Check Connection', 'notify-odoo') ; ?>"/>  
    </form> 
  <br>
  <br>  
 <b><?php echo __('Debugging'); ?>:</b><br/>     
  <br>
  <form action="?page=notifyodoo_settings&action=updateSettings" method="post">
    <input type="submit" name="add_customer_to_queue" class="button button-primary" value="<?php echo __('Add last customer to queue', 'notify-odoo') ; ?>"/>
    &nbsp;
    <?php echo __('or specify ID: ', 'notify-odoo'); ?>
    <input style="width:60px;" type="text" name="add_customer_to_queue_id" value="" autocomplete="off"/><br/> 
  </form>
  <br/>  
  <form action="?page=notifyodoo_settings&action=updateSettings" method="post">
    <input type="submit" name="add_order_to_queue" class="button button-primary" value="<?php echo __('Add last order to queue', 'notify-odoo') ; ?>"/>
    &nbsp;
    <?php echo __('or specify ID: ', 'notify-odoo'); ?>
    <input style="width:60px;" type="text" name="add_order_to_queue_id" value="" autocomplete="off"/><br/> 
  </form>
  <br/> 
  <form action="<?php echo admin_url('admin-ajax.php'); ?>" target="_blank">
    <input type="hidden" name="action" value="notify_odoo_process_items"/>   
    <input type="hidden" name="item_type" value="new_customer"/>  
    <input type="submit" class="button button-primary" value="<?php echo __('Send last customer with debug info', 'notify-odoo') ; ?>"/>
    &nbsp;
    <?php echo __('or specify ID: ', 'notify-odoo'); ?>
    <input style="width:60px;" type="text" name="item_id" value="" autocomplete="off"/><br/> 
  </form>
  <br/>  
  <form action="<?php echo admin_url('admin-ajax.php'); ?>?action=notify_odoo_process_items" method="get" target="_blank">
    <input type="hidden" name="action" value="notify_odoo_process_items"/>    
    <input type="hidden" name="item_type" value="new_order"/>
    <input type="submit" class="button button-primary" value="<?php echo __('Send last order with debug info', 'notify-odoo') ; ?>"/>
    &nbsp;
    <?php echo __('or specify ID: ', 'notify-odoo'); ?>
    <input style="width:60px;" type="text" name="item_id" value="" autocomplete="off"/><br/> 
  </form>
  <br/>  
  <br>
  <br> 
 <b><?php echo __('Error log'); ?>:</b><br/>
  <?php 
      include_once(Pektsekye_NO()->getPluginPath() . 'Model/OdooApi.php');  
      $file = Pektsekye_NO()->getPluginPath() . Pektsekye_NotifyOdoo_Model_OdooApi::LOG_FILE;      
  ?>  
  <?php echo __('Log file location', 'notify-odoo'); ?>:<br/>  
  <?php echo str_replace(ABSPATH, '', $file); ?><br/>
  <?php if (file_exists($file) && filesize($file) > 0): ?> 
    <form action="?page=notifyodoo_settings&action=updateSettings" method="post" onsubmit="return confirm('<?php echo esc_attr__('Are you sure you want to clear the log file?', 'notify-odoo') ; ?>');">
      <?php echo sprintf(__('Download the <a href="%s" target="_blank">log file</a>.', 'notify-odoo'), '?page=notifyodoo_settings&action=downloadLogFile'); ?>
      &nbsp;&nbsp;
      <input type="submit" name="clear_log_file" class="button button-primary" value="<?php echo __('Clear log file', 'notify-odoo') ; ?>"/> <br/>
    </form> 
  <?php else: ?>
    (<?php echo sprintf(__('the file is empty', 'notify-odoo'), '?page=notifyodoo_settings&action=downloadLogFile'); ?>) <br/>      
  <?php endif; ?>   
  <br>
  <br>   
  <br>
  <b><?php echo __('Documentation'); ?>:</b><br/>        
  <?php echo __('README', 'notify-odoo'); ?>:<br/>  
  <a href="http://hottons.com/demo/wp/no/modifications/odoo_api/README.html" target="_blank">http://hottons.com/demo/wp/no/modifications/odoo_api/README.html</a><br/>           
  <br/>
  <?php echo __('Plugin page', 'notify-odoo'); ?>:<br/>  
  <a href="https://wordpress.org/plugins/notify-odoo/" target="_blank">https://wordpress.org/plugins/notify-odoo/</a><br/>  
  <?php echo __('Odoo API modification page', 'notify-odoo'); ?>:<br/>  
  <a href="http://hottons.com/no_modifications" target="_blank">http://hottons.com/no_modifications</a><br/>   
  <br>   
  <br>
  <br>   
  <br>
  <br>   
  <br>      
</div>






















