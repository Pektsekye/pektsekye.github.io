<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class Pektsekye_NotifyOdoo_Controller_Adminhtml_No_Settings {

 
  public function predispatch(){
    
    $action = isset($_GET['action']) ? sanitize_text_field($_GET['action']) : 'index';
         
    switch($action){         
      case 'updateSettings':

        if (isset($_POST['save_configuration'])){
    
          $this->_updateSettings();

          $message = __('Settings were saved.', 'notify-odoo');              
          Pektsekye_NO()->setMessage($message);
      
        } elseif (isset($_POST['check_connection'])){

          $this->_updateSettings();
      
          Pektsekye_NO()->setDebugEnabled(true);
       
          $observer = new Pektsekye_NotifyOdoo_Model_Observer();
   
          $observer->notify();
      
          $result = Pektsekye_NO()->getDebugResult();
      
          if (isset($result['response']) && $result['response'] == 5){
            Pektsekye_NO()->setMessage(__('Connection is good. The notification has been sent.', 'notify-odoo'));                       
          } else {
            Pektsekye_NO()->setMessage(__('Connection error. Cannot send notification.', 'notify-odoo'), 'error'); 
          }  
       
        } elseif (isset($_POST['add_customer_to_queue'])){
    
          $customerId = 0;
          if (isset($_POST['add_customer_to_queue_id']) && !empty($_POST['add_customer_to_queue_id'])){
            $customerId = (int) $_POST['add_customer_to_queue_id'];
            $customer = null;
            try{
              $customer = new WC_Customer($customerId);
            } catch (Exception $e){}
            if (empty($customer) || $customer->get_email() == null){
              $customerId = 0;
            }
          } 
      
          if (empty($customerId)){
            include_once(Pektsekye_NO()->getPluginPath() . 'Model/CronJob.php');		
            $cronJob = new Pektsekye_NotifyOdoo_Model_CronJob();          
                  
            $customerIds = $cronJob->get_customer_ids();
            if (!empty($customerIds)){
              $customerId = end($customerIds);
            }
          }
      
          if (!empty($customerId)){
            include_once(Pektsekye_NO()->getPluginPath() . 'Model/Notification.php');		
            $notification = new Pektsekye_NotifyOdoo_Model_Notification(); 
        
            $notification->addNotification('new_customer', $customerId);
        
            $message = __('Customer has been added to the queue.', 'notify-odoo');              
            Pektsekye_NO()->setMessage($message);           
          }           
        } elseif (isset($_POST['add_order_to_queue'])){
    
          $orderId = 0;
          if (isset($_POST['add_order_to_queue_id']) && !empty($_POST['add_order_to_queue_id'])){
            $orderId = (int) $_POST['add_order_to_queue_id'];
            $order = wc_get_order($orderId);
            if (empty($order)){
              $orderId = 0;
            }
          } 
      
          if (empty($orderId)){
            include_once(Pektsekye_NO()->getPluginPath() . 'Model/CronJob.php');		
            $cronJob = new Pektsekye_NotifyOdoo_Model_CronJob();
                  
            $orderIds = $cronJob->get_order_ids();
            if (!empty($orderIds)){
              $orderId = end($orderIds);
            }
          }
      
          if (!empty($orderId)){
            include_once(Pektsekye_NO()->getPluginPath() . 'Model/Notification.php');		
            $notification = new Pektsekye_NotifyOdoo_Model_Notification(); 
        
            $notification->addNotification('new_order', $orderId);
        
            $message = __('Order has been added to the queue.', 'notify-odoo');              
            Pektsekye_NO()->setMessage($message);           
          } 
      
        } elseif (isset($_POST['export_customers'])){
      
          $startFromId = 0;
          if (isset($_POST['start_from_id']) && !empty($_POST['start_from_id'])){
            $startFromId = (int) $_POST['start_from_id'];
          }
       
          include_once(Pektsekye_NO()->getPluginPath() . 'Model/CronJob.php');		
          $cronJob = new Pektsekye_NotifyOdoo_Model_CronJob();          
      
          $customerIds = $cronJob->get_customer_ids();
          if (!empty($customerIds)){
        
            include_once(Pektsekye_NO()->getPluginPath() . 'Model/Notification.php');		
            $notification = new Pektsekye_NotifyOdoo_Model_Notification(); 		                  
        
            foreach($customerIds as $customerId){
              if ($startFromId > 0){
                if ($customerId != $startFromId){
                  continue;
                } else {
                  $startFromId = 0;
                }
              }
          
              $notification->addNotification('new_customer', $customerId);
                                  
            }
        
            $message = __('Customers have been added to the queue.', 'notify-odoo');              
            Pektsekye_NO()->setMessage($message);                        
          }      
        
        } elseif (isset($_POST['export_orders'])){
      
          $startFromId = 0;
          if (isset($_POST['start_from_id']) && !empty($_POST['start_from_id'])){
            $startFromId = (int) $_POST['start_from_id'];
          }
       
          include_once(Pektsekye_NO()->getPluginPath() . 'Model/CronJob.php');		
          $cronJob = new Pektsekye_NotifyOdoo_Model_CronJob();          
      
          $orderIds = $cronJob->get_order_ids();
          if (!empty($orderIds)){
        
            include_once(Pektsekye_NO()->getPluginPath() . 'Model/Notification.php');		
            $notification = new Pektsekye_NotifyOdoo_Model_Notification(); 		                  
        
            foreach($orderIds as $orderId){
              if ($startFromId > 0){
                if ($orderId != $startFromId){
                  continue;
                } else {
                  $startFromId = 0;
                }
              }
          
              $notification->addNotification('new_order', $orderId);
                                  
            }
        
            $message = __('Orders have been added to the queue.', 'notify-odoo');              
            Pektsekye_NO()->setMessage($message);                        
          }        
                         
        } elseif (isset($_POST['clear_queue'])){
          include_once(Pektsekye_NO()->getPluginPath() . 'Model/Notification.php');		
          $notification = new Pektsekye_NotifyOdoo_Model_Notification();
      
          $notification->deleteNotifications(); 
      
          $message = __('The cron action queue has been cleared.', 'notify-odoo');              
          Pektsekye_NO()->setMessage($message);
      
        } elseif (isset($_POST['clear_queue_history'])){
      
          update_option('notifyodoo_cron_action_last_processed_items', array(), false); 
      
          $message = __('The queue history has been cleared.', 'notify-odoo');              
          Pektsekye_NO()->setMessage($message);          
        } elseif (isset($_POST['schedule'])){
    
          include_once(Pektsekye_NO()->getPluginPath() . 'Model/CronJob.php');
          $cronJob = new Pektsekye_NotifyOdoo_Model_CronJob();
      
          $cronJob->schedule(); 	        
                      
          $message = __('The Odoo API cron action has been scheduled.', 'notify-odoo');              
          Pektsekye_NO()->setMessage($message);
      
        } elseif (isset($_POST['unschedule'])){
    
          include_once(Pektsekye_NO()->getPluginPath() . 'Model/CronJob.php');
          $cronJob = new Pektsekye_NotifyOdoo_Model_CronJob();
      
          $cronJob->unschedule();                 
                                
          $message = __('The Odoo API cron action has been unscheduled.', 'notify-odoo');              
          Pektsekye_NO()->setMessage($message);
        
       
        } elseif (isset($_POST['check_odoo_api_connection'])){
     
          include_once(Pektsekye_NO()->getPluginPath() . 'Model/OdooApi.php');		
          $odooApi = new Pektsekye_NotifyOdoo_Model_OdooApi();          
      
          $odooApiClassFile = str_replace(ABSPATH, '', Pektsekye_NO()->getPluginPath() . 'Model/OdooApi.php');
          $logFile = str_replace(ABSPATH, '', Pektsekye_NO()->getPluginPath() . $odooApi::LOG_FILE);
      
      
          if (!$odooApi->connectionParametersSpecified()){
            Pektsekye_NO()->setMessage(sprintf(__('Connection error.<br/> Specify your odoo URL, user, API key and database name in the file:<br/> %s', 'notify-odoo'), $odooApiClassFile), 'error'); 
          } else {
      
            $odooApi->setDebug(true);
        
            $odooApi->initApi();
            
            $uid = $odooApi->connectToOdoo();
   
            if (!empty($uid)){
              Pektsekye_NO()->setMessage(__('Connection is good.', 'notify-odoo'));
              update_option('notifyodoo_cron_action_last_successful_connection', time());                       
            } else {            
              Pektsekye_NO()->setMessage(sprintf(__('Connection error.<br/> Check your odoo URL, user, API key and database name in the file:<br/> %s<br/> Also the error log file:<br/> %s <br/> can contain more details about the connection error.', 'notify-odoo'), $odooApiClassFile, $logFile), 'error'); 
            }
          }        
               
        } elseif (isset($_POST['clear_log_file'])){
    
          include_once(Pektsekye_NO()->getPluginPath() . 'Model/OdooApi.php');  
          $odooApi = new Pektsekye_NotifyOdoo_Model_OdooApi();   
         
          $odooApi->clearLogFile();
      
          $message = __('The log file has beed cleared.', 'notify-odoo');                          
          Pektsekye_NO()->setMessage($message);  
                                                
        }               
      break; 
      case 'downloadLogFile':

        include_once(Pektsekye_NO()->getPluginPath() . 'Model/OdooApi.php');  
        $odooApi = new Pektsekye_NotifyOdoo_Model_OdooApi();   

        if (file_exists(Pektsekye_NO()->getPluginPath() . $odooApi::LOG_FILE)){  
          $odooApi->downloadLogFile();
          exit;
        } else {
          Pektsekye_NO()->setMessage(__('File does not exist.', 'notify-odoo'), 'error');
        }                
      break;                                                                                                                        
    }      
  }	 
  
  
  protected function _updateSettings(){
    $url = isset($_POST['notify_url']) ? sanitize_text_field(stripslashes($_POST['notify_url'])) : '' ; 
    update_option('notifyodoo_url', $url);
    
    $notifyAboutCustomer = isset($_POST['notify_about_new_customer']) && $_POST['notify_about_new_customer'] == 1 ? 1 : 0;    
    update_option('notifyodoo_notify_about_new_customer', $notifyAboutCustomer); 
       
    $notifyAboutOrder = isset($_POST['notify_about_new_order']) && $_POST['notify_about_new_order'] == 1 ? 1 : 0;    
    update_option('notifyodoo_notify_about_new_order', $notifyAboutOrder);
        
    $addTrackingImage = isset($_POST['add_tracking_image']) && $_POST['add_tracking_image'] == 1 ? 1 : 0;    
    update_option('notifyodoo_add_tracking_image', $addTrackingImage);
    
    $allowIpAddress = isset($_POST['allow_ip_address']) ? sanitize_text_field($_POST['allow_ip_address']) : '';
    update_option('notifyodoo_allow_ip_address', $allowIpAddress);            
  }  


}
