<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class Pektsekye_NotifyOdoo_Block_Adminhtml_No_Settings {
        
  protected $_notification;
  protected $_cronJob;  
          
          
	public function __construct() {
    include_once(Pektsekye_NO()->getPluginPath() . 'Model/Notification.php');		
		$this->_notification = new Pektsekye_NotifyOdoo_Model_Notification();
		
    include_once(Pektsekye_NO()->getPluginPath() . 'Model/CronJob.php');
    $this->_cronJob = new Pektsekye_NotifyOdoo_Model_CronJob();   			
	}
	

  public function getNotifyUrl() 
  {   
    return get_option('notifyodoo_url', '');
  }


  public function getNotifyAboutNewCustomer() 
  {   
    return get_option('notifyodoo_notify_about_new_customer', 0);
  }


  public function getNotifyAboutNewOrder() 
  {   
    return get_option('notifyodoo_notify_about_new_order', 0);
  }
  

  public function getAddTrackingImage() 
  {   
    return get_option('notifyodoo_add_tracking_image', 0);
  }      
      
      
  public function getAllowIpAddress() 
  {   
    return get_option('notifyodoo_allow_ip_address', '');
  }
      
      
  public function getLastAccessIpAddress() 
  {   
    return get_option('notifyodoo_last_access_ip_address', '');
  } 
      
      
  public function getNotifications() 
  {  
    $ntfs = array();
     
    $rows = (array) $this->_notification->getNotifications();
    foreach($rows as $r){
      if ($r['type'] == 'default'){
        continue;
      }
      $ntfs[$r['type']][] = $r['item_id'];
    }
    
    return $ntfs;
  } 
      
      
  public function getIsScheduled() 
  {   
    return $this->_cronJob->isScheduled();
  }      
      
      
  public function getLastExecutedTimestemp() 
  {      
    return get_option('notifyodoo_cron_action_last_executed', '');
  }
      
      
  public function getLastProcessedItems() 
  {      
    return get_option('notifyodoo_cron_action_last_processed_items', array());
  }      


  public function getSendAgainLink($itemType, $itemId)  
  {
    $itemType = $itemType == 'new_order' ? 'new_order' : 'new_customer';
    $itemId = (int) $itemId;           
    return admin_url('admin-ajax.php') .'?action=notify_odoo_process_items&item_type='.$itemType.'&item_id='.$itemId;   
  } 
   
        
  public function getLastSuccessfulConnection() 
  {      
    return get_option('notifyodoo_cron_action_last_successful_connection', 0);
  }
  
  
  public function formatDateFromTimestemp($timestamp){  
    $date = '';
    if (!empty($timestamp)){
      $date_string = date( 'Y-m-d H:i:s', $timestamp); 
      $datetime = date_create( $date_string, new DateTimeZone( 'UTC' ) );
      $date = $datetime->setTimezone( wp_timezone() )->format('F j, Y H:i O'); // wp_timezone() for timezone set in wordpress admin panel settings
    }  
    return $date;                
  }      
  
    
  public function getMessage() {
    return Pektsekye_NO()->getMessage();
  }
  
  
  public function getDebugResult() {
    return Pektsekye_NO()->getDebugResult();
  } 
 
 
  public function toHtml()
  {   
    include_once( Pektsekye_NO()->getPluginPath() . 'view/adminhtml/templates/no/settings.php');
  }
   

}