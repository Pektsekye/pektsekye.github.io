<?php
if (!defined('ABSPATH')) exit;

class Pektsekye_NotifyOdoo_Model_CronJob {  

  protected $_notification;
  protected $_odooApi;

  const CRON_ACTION_NAME = 'notify_odoo_cron_action';
  const CRON_ACTION_INTERVAL_NAME = '1_min_notify_odoo';
  const CRON_ACTION_INTERVAL_SEC = 60;  
  
  protected $_procession_limit = 10; 
  
  
  public function __construct(){ 
    include_once(Pektsekye_NO()->getPluginPath() . 'Model/Notification.php');		
		$this->_notification = new Pektsekye_NotifyOdoo_Model_Notification();
		
    include_once(Pektsekye_NO()->getPluginPath() . 'Model/OdooApi.php');		
		$this->_odooApi = new Pektsekye_NotifyOdoo_Model_OdooApi();

    add_action(self::CRON_ACTION_NAME, array($this, 'cron_action'));

    add_filter('cron_schedules', function ( $schedules ) {
       $schedules[self::CRON_ACTION_INTERVAL_NAME] = array(
           'interval' => self::CRON_ACTION_INTERVAL_SEC,
           'display' => __('Once every minute')
       );
       return $schedules;
    } );
         		
  }	 
  
  
	public function cron_action() {

    update_option('notifyodoo_cron_action_last_executed', time());

    $this->processItems();
  }
  
  
	public function processItemsAjax(){
    
    if (!current_user_can('administrator')){
      echo __('Access only for administrator', 'notify-odoo');
      exit;
    }
       
    $this->_odooApi->setDebug(true);
    $this->_odooApi->setDebugDisplay(true);  
    $this->_odooApi->setDebugData(true);
    $this->_odooApi->setWriteToLogFile(false);
        
    $ntfs = array();
    
    if (isset($_GET['item_type'])) {
      $type = in_array($_GET['item_type'], array('new_order','new_customer')) ? $_GET['item_type'] : '';
      $itemId = isset($_GET['item_id']) && !empty($_GET['item_id']) ? (int) $_GET['item_id'] : 0;
      
      if ($itemId == 0){
        if ($type == 'new_order'){
          $ids = $this->get_order_ids();
          if (!empty($ids)){
            $itemId = end($ids);
          }     
        } elseif ($type == 'new_customer') {
          $ids = $this->get_customer_ids();
          if (!empty($ids)){
            $itemId = end($ids);
          }
        }      
      }
      
      if (!empty($type) && !empty($itemId)){
        $ntfs[$type] = array(array('type' => $type, 'item_id' => $itemId,'notification_id' => 1));
      }  
    }
    
    $this->processItems($ntfs);	
    
	  exit;
	}
	

	public function processItems($ntfs = array()){
	
    if ($this->_odooApi->_debug){  
      $this->_odooApi->writeLog(' ');  
      $this->_odooApi->writeLog(' *** Start processing items *** ');
    }

    if (empty($ntfs)) {    
      $rows = (array) $this->_notification->getNotifications();
      foreach($rows as $r){
        if ($r['type'] == 'default'){
          continue;
        }
        $ntfs[$r['type']][] = $r;
      }   
    }
  
    if (count($ntfs) == 0){
      if ($this->_odooApi->_debug){
        $this->_odooApi->writeLog('There are no items in the queue.');
      } 
      return;      
    }  
  
    if ($this->_odooApi->_debug_data){
      $this->_odooApi->writeLog('DATA 1. items to process: ' . print_r($ntfs, true));
      $this->_odooApi->writeLog('  ');
    }
    
    if (!$this->_odooApi->connectionParametersSpecified()){      
      $odooApiClassFile = str_replace(ABSPATH, '', Pektsekye_NO()->getPluginPath() . 'Model/OdooApi.php');
      $this->_odooApi->writeLog('Error: connection parameters are not specified. Specify odoo URL, user, API key and database name in the file: ' . $odooApiClassFile);
      return;     
    }
    
    $this->_odooApi->initApi();
    
    $version = $this->_odooApi->getOdooVersion();

    if (!empty($version)){
      $this->_odooApi->writeLog('Odoo version - ' . $version, 'info');               
    } else {
      $this->_odooApi->writeLog('Error: cannot process items without access to Odoo');
      return;  
    }    
    
    $uid = $this->_odooApi->connectToOdoo();

    if (!empty($uid)){
      $this->_odooApi->writeLog('Login successful.', 'info');
      update_option('notifyodoo_cron_action_last_successful_connection', time());                
    } else {
      $this->_odooApi->writeLog('Error: cannot process items without access to Odoo');
      return;  
    }
        
    $lastProcesed = get_option('notifyodoo_cron_action_last_processed_items', array());
    
    $processedItemsCount = 0;
    
    if (isset($ntfs['new_customer'])){
      foreach($ntfs['new_customer'] as $r){
      
        if ($processedItemsCount >= $this->_procession_limit){
          break;
        }
        
        $customerId = (int) $r['item_id'];
        $notifId = (int) $r['notification_id'];
            
        $this->_odooApi->_connectionError = false;
      
        $newId = $this->_odooApi->transferCustomer($customerId);
      
        if (!$this->_odooApi->_connectionError){
          $this->_notification->deleteNotification($notifId);         
        }

        $this->updateLastProcessed($lastProcesed, $r['type'], $r['item_id'], $newId, $this->_odooApi->_item_error_code, $this->_odooApi->_connectionError);
 
        $processedItemsCount++;        
      }
    } 
  
    if (isset($ntfs['new_order'])){
      foreach($ntfs['new_order'] as $r){
      
        if ($processedItemsCount >= $this->_procession_limit){
          break;
        }
            
        $orderId = (int) $r['item_id'];
        $notifId = (int) $r['notification_id'];
            
        $this->_odooApi->_connectionError = false;
      
        $newId = $this->_odooApi->transferOrder($orderId);
      
        if (!$this->_odooApi->_connectionError){
          $this->_notification->deleteNotification($notifId);          
        }
        
        $this->updateLastProcessed($lastProcesed, $r['type'], $r['item_id'], $newId, $this->_odooApi->_item_error_code, $this->_odooApi->_connectionError);
         
        $processedItemsCount++;        
      }    
      
    }

    update_option('notifyodoo_cron_action_last_processed_items', $lastProcesed, false);        	
	}
 
  
  protected function updateLastProcessed(&$lastProcesed, $itemType, $itemId, $newId, $itemErrorCode, $isConnectionError){
    
    $timestamp = time();
    
    $statusCode = '';
    if (!empty($newId)){ 
       $statusCode = 'successful_transfer';       
    } else {
      if ($itemErrorCode == 1){
        $statusCode = 'skipped'; 
      } elseif($isConnectionError) {
        $statusCode = 'connection_error';             
      } else {
        $statusCode = 'failed_transfer';
      }      
    }
    
    $lastProcesed[$statusCode] = array('type' => $itemType, 'id' => $itemId, 'timestemp' => $timestamp);        
    $lastProcesed['last_item'] = array('type' => $itemType, 'id' => $itemId, 'timestemp' => $timestamp, 'status_code' => $statusCode);    
  }
  
  
  public function schedule(){
  //  if (wp_next_scheduled(self::CRON_ACTION_NAME) == false) {
      wp_schedule_event(time(), self::CRON_ACTION_INTERVAL_NAME, self::CRON_ACTION_NAME);
   // }   
  }  
  
  
  public function unschedule(){
    wp_clear_scheduled_hook(self::CRON_ACTION_NAME);   
  }    


  public function isScheduled(){
    return wp_next_scheduled(self::CRON_ACTION_NAME) !== false;   
  }
  
  
  public function get_order_ids(){
    global $wpdb;
    $statuses = array_keys(wc_get_order_statuses());
    $statuses = implode( "','", $statuses );

    return $wpdb->get_col( "
        SELECT ID FROM {$wpdb->prefix}posts
        WHERE post_type LIKE 'shop_order'
        AND post_status IN ('$statuses')
        ");
  }
    
    
  public function get_customer_ids(){
  
     $customer_query = new WP_User_Query(
      array(
         'fields' => 'ID',
         'role' => 'customer',
         'orderby' => 'registered'         
      )
   );

   return $customer_query->get_results();
  }	
			

}
