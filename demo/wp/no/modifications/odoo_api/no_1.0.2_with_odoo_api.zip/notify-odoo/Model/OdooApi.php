<?php
if (!defined('ABSPATH')) exit;

class Pektsekye_NotifyOdoo_Model_OdooApi {  

  protected $_erp;

  protected $_odoo_url = 'http://127.0.0.1:8069';
    
  protected $_odoo_user = 'admin';
  protected $_odoo_api_key = 'ba888f410c8e8f145d9589e03ba03579809052dc';
  protected $_odoo_db = 'odoo17';  

  const ORDER_CODE_PREFIX = 'wc_order_';   
  
  const LOG_FILE = "var/errors.log";
      
  public $_connectionError;
  public $_debug = false;
  public $_debug_display = false;    
  public $_debug_data = false; 
  public $_write_to_log_file = true;

  public $_item_error_message = '';
  public $_item_error_code = 0;   // 0 failed to send, 1 already exists 
          
  public $_connectionErrorCode = 777;
  
           
  public function __construct(){ 
         		
  }	
  
  
	public function connectionParametersSpecified(){	
	  return !empty($this->_odoo_url) && !empty($this->_odoo_user) && !empty($this->_odoo_api_key) && !empty($this->_odoo_db);	
	}


	public function setDebug($val = true){	
	  $this->_debug = $val;	
	}


	public function setDebugDisplay($val = true){	
	  $this->_debug_display = $val;	
	}


	public function setDebugData($val = true){	
	  $this->_debug_data = $val;	
	}
	
	
	public function setWriteToLogFile($val = true){	
	  $this->_write_to_log_file = $val;	
	}
	
		
	public function transferCustomer($customerId){
    if ($this->_debug){
      $this->writeLog('  ');
      $this->writeLog('transferCustomer with id - '. $customerId);
    }
    	
    $customer = new WC_Customer($customerId);
    
    $data = $customer->get_data();
  
    if ($this->_debug_data){
      $this->writeLog('DATA 2. customer : ' . print_r($data, true));
      $this->writeLog('  ');
    } 
    
    $newId = 0;   
    if (!empty($data['email'])){      
      $newId = $this->createNewOdooCustomer($data);
    }
    
    return $newId;	    	
	}


	public function transferOrder($orderId){
    if ($this->_debug){
      $this->writeLog('  ');    
      $this->writeLog('transferOrder with id - '. $orderId);
    }
    	
    $order = new WC_Order($orderId);

    /*
      'first_name' 
      'last_name' 
      'email' 
      'billing' 
      'shipping'

      'date_created'

      'line_items'
      'sku'
      'product_id'
      'name'
      'price'
      'quantity'
    */

    $data = $order->get_data();
    
    if ($this->_debug_data){
      $this->writeLog('DATA 3. order base data : ' . print_r($order->get_base_data(), true));
      $this->writeLog('  ');
    }
    
    $newId = 0;        
    if (!empty($data['date_created'])){      
      $newId = $this->createNewOdooOrder($data);
    }
    
    return $newId;    	    	
	}
	
	
	public function initApi(){
    require_once(Pektsekye_NO()->getPluginPath(). 'simbigo_openerp_api/OpenERP.php');
    require_once(Pektsekye_NO()->getPluginPath(). 'simbigo_openerp_api/XmlRpcClient.php');        
    
    $this->_erp = new OpenERP($this->_odoo_url, 'utf-8', $this->_connectionErrorCode);	
	}	
	
	
	public function getOdooVersion(){
	    
    $this->writeLog('Trying to access odoo server without login and get odoo version.', 'info');
    
    $version = '';
    
    try {
  
      $version = $this->_erp->version();

      if (empty($version)){
        $this->writeLog('Error: cannot access odoo server and get odoo version. Login and API key are not required for this action. Please verify odoo URL. Current URL - ' . $this->_odoo_url);      
      }
            
    } catch (Exception $e) {
      $this->writeLog('Error: cannot access odoo server and get odoo version. Login and API key are not required for this action. Please verify odoo URL. Current URL - ' . $this->_odoo_url . ' Error message: ' . $e->getMessage());      
    } 
     
    return $version;	
	}
		
	
	public function connectToOdoo(){
	    
    $this->writeLog('Trying to connect to Odoo.', 'info');    
    
    $uid = 0;
    
    try {
  
      $uid = $this->_erp->login($this->_odoo_db, $this->_odoo_user, $this->_odoo_api_key);
      
      if (empty($uid)){
        $this->writeLog('Error: cannot login to Odoo.');      
      }
            
    } catch (Exception $e) {
      $this->writeLog('Error: cannot login to Odoo. ' . $e->getMessage());      
    } 
     
    return $uid;	
	}
	
	
	public function createNewOdooCustomer($data){

	  $this->_item_error_code = 0;
	      	
    $this->writeLog('Trying to create new odoo customer with email - '. (isset($data['email']) ? $data['email'] : ''), 'info');
        
    $newCustomerId = 0; 
        
    try {   
  
      if (!isset($data['email']) || empty($data['email'])){
        $this->writeLog('Error: cannot create customer. Customer email is not specified. Customer id ' . $data['id']);
        $this->_item_error_code = 0; // failed to send           
        return 0;
      }
      
      $email = trim($data['email']);
      
      sleep(1);
      $ids = $this->_erp->search('res.partner', array(array('email', '=', $email)), 0, 1);

      if (count($ids) > 0){ // customer with such email already exists
        $this->writeLog('Error: cannot create customer. Customer with email "' .$email .'" already exists. Customer id ' . $data['id']);
        $this->_item_error_code = 1; // skipped. already exists         
        return 0;
      }  
    
      $fName = isset($data['first_name']) ? $data['first_name'] : '';
      $lName = isset($data['last_name']) ? $data['last_name'] : '';        
    
      $createData = array(
        'type' => 'contact',
        'company_name' => isset($data['billing']['company']) ? $data['billing']['company'] : '',                        
        'name' => $fName . ' ' . $lName,
        'phone' => isset($data['billing']['phone']) ? $data['billing']['phone'] : '',                        
        'email' => $email,                             
        );
        
      $this->writeLog('DATA 4. create res.partner : ' . print_r($createData, true), 'data');
      $this->writeLog('  ', 'data');
          
      sleep(1);
      $newCustomerId = $this->_erp->create('res.partner', $createData);
    
      if (empty($newCustomerId)){
        $this->writeLog('Error: cannot create customer. Customer id ' . $data['id'] . ', email '. $data['email'] . ', data: ' . print_r($createData, true));
        $this->_item_error_code = 0; // failed to send        
        return 0;        
      }
      
      $this->writeLog('New odoo customer created with id - ' . $newCustomerId, 'info');           
   
      $address = isset($data['billing']) ? $data['billing'] : array();
       
      if ((isset($address['first_name']) && !empty($address['first_name'])) || 
          (isset($address['last_name']) && !empty($address['last_name'])) || 
          (isset($address['company']) && !empty($address['company']))){
         
        $fName = isset($address['first_name']) ? $address['first_name'] : '';
        $lName = isset($address['last_name']) ? $address['last_name'] : ''; 
                               
        $createData = array(
              'type' => 'invoice',
              'parent_id' => $newCustomerId,          
              'name' => $fName . ' ' . $lName,
              'company_name' => isset($address['company']) ? $address['company'] : '',
              'street' => isset($address['address_1']) ? $address['address_1'] : '',
              'street2' => isset($address['address_2']) ? $address['address_2'] : '',
              'city' => isset($address['city']) ? $address['city'] : '',
              'zip' => isset($address['postcode']) ? $address['postcode'] : '',
              'phone' => isset($address['phone']) ? $address['phone'] : '',
              'email' => isset($address['email']) ? $address['email'] : ''                            
              );
    
        if (isset($address['country']) && !empty($address['country'])){
          $countryCode = strtoupper(trim($address['country']));

          sleep(1);
          $ids = $this->_erp->search('res.country', array(array('code', '=', $countryCode)), 0, 1);                        
          
          if (count($ids) > 0){
            $countryId = (int) $ids[0];
          
            $createData['country_id'] = $countryId;
          
            if (isset($address['state']) && !empty($address['state'])){
              $stateCode = strtoupper(trim($address['state']));

              sleep(1);
              $ids = $this->_erp->search('res.country.state', array(array('country_id', '=', $countryId), array('code', '=', $stateCode)), 0, 1);
              
              if (count($ids) > 0){                  
                $createData['state_id'] = (int) $ids[0];                  
              }
            }
          } 
        }
        
        $this->writeLog('DATA 5. create billing address res.partner : ' . print_r($createData, true), 'data');
        $this->writeLog('  ', 'data');
              
        sleep(1);
        $newCustomerInvoiceAddressId = $this->_erp->create('res.partner', $createData);
        
        if (!empty($newCustomerInvoiceAddressId)){
          $this->writeLog('Billing address added to the customer', 'info');
        } else {
          $this->writeLog('Error: cannot create billing address for customer. Customer id ' . $data['id'] . ', email '. $data['email'] . ', data: ' . print_r($createData, true));
          $this->_item_error_code = 0; // failed to send        
        }
                                  
      }  
    
    } catch (Exception $e) {
          
      $this->writeLog('Error cannot send customer id - ' . $data['id'] . ', email - ' . $data['email']);     
      $this->writeLog('Error message: ' . $e->getMessage());
      $this->writeLog('  ');      
      $this->writeLog('ErrorTrace: ' . $e->getTraceAsString()); 
           
      $this->_item_error_code = 0; // failed to send
      
      if ($e->getCode() == $this->_connectionErrorCode){ 
        $this->_connectionError = true; 
      }
    }    
    
    return $newCustomerId;	
	
	}
	
	
	public function createNewOdooOrder($data){
		
    $this->_item_error_code = 0; // failed to send
          
    $this->writeLog('Trying to create new odoo order with order id - '. (isset($data['id']) ? $data['id'] : ''), 'info');

    $newOrderId = 0;
        
    try {
      
      $partnerId = 0;
       
      $billing = isset($data['billing']) ? $data['billing'] : array();
      if (!empty($billing)){

        $email = isset($billing['email']) ? trim($billing['email']) : '';
             
        sleep(1);
        $ids = $this->_erp->search('res.partner', array(array('email', '=', $email)), 0, 1);
        
        if (count($ids) > 0){
          $this->writeLog('Customer for the current order found by email "'. $email .'". Partner id - ' . $ids[0], 'info');      
           
          $partnerId = (int) $ids[0];
        
        } else {
      
          $createData = array(
            'first_name' => isset($billing['first_name']) ? $billing['first_name'] : '',
            'last_name' => isset($billing['last_name']) ? $billing['last_name'] : '',
            'email' => $email,
            'billing' => $billing,
            'shipping' => isset($billing['shipping']) ? $billing['shipping'] : ''
          );
          
          $this->writeLog('DATA 6. create cutomer from order billing info : ' . print_r($createData, true), 'data');
          $this->writeLog('  ', 'data');
          
          $partnerId = $this->createNewOdooCustomer($createData);
        }          
      }
  
      if (empty($partnerId)){
        $this->writeLog('Error: cannot create order without customer. Order id - ' . $data['id']);
        $this->_item_error_code = 0; // failed to send                
        return 0;
      }

      $dateCreated = isset($data['date_created']) ? $data['date_created'] : '';
      
      if (!empty($dateCreated)){
        if (is_a($dateCreated, 'WC_DateTime')){ 
          $dateCreated =  gmdate( 'Y-m-d H:i:s', $dateCreated->getTimestamp()); //GMT time. Use $dateCreated->getOffsetTimestamp() for woocommerce local time.
        } else {      
          $dateCreated = str_replace('T', ' ', $dateCreated);  // '2019-08-26T21:53:49' -> '2019-08-26 21:53:49'
        }
      } else {
        $dateCreated = date('Y-m-d H:i:s', time());
      }
    
      $newOrderName = self::ORDER_CODE_PREFIX . (isset($data['number']) ? $data['number'] : '');  
    
      sleep(1);
      $ids = $this->_erp->search('sale.order', array(array('name', '=', $newOrderName)), 0, 1);
      
      if (count($ids) > 0){
        $this->writeLog('Error: cannot create order. Order with code "' . $newOrderName . '" already exists. Order id - ' . $data['id']);
        $this->_item_error_code = 1; // already exists                
        return 0;        
      }
   
  /*
      #   state = fields.Selection([
      #        ('draft', 'Quotation'),
      #        ('sent', 'Quotation Sent'),
      #        ('sale', 'Sales Order'),
      #        ('done', 'Locked'),
      #        ('cancel', 'Cancelled'),
      #optional fields
      #              'pricelist_id': request.env.ref('product.list0').id,
      #              'partner_invoice_id': request.env.ref('base.res_partner_address_25').id,
      #              'partner_shipping_id': request.env.ref('base.res_partner_address_25').id,
      #              'confirmation_date' : (datetime.now()-timedelta(days=7)).strftime('%Y-%m-%d %H:%M:%S'),

  */            
  
      $createData = array(
            'name' => $newOrderName,
            'partner_id' => $partnerId,
            'date_order' => $dateCreated,
            'state' => 'sale'
          );
          
      $this->writeLog('DATA 7. create sale.order : ' . print_r($createData, true), 'data');
      $this->writeLog('  ', 'data');
            
      sleep(1);
      $newOrderId = $this->_erp->create('sale.order', $createData);
    
      if (empty($newOrderId)){
        $this->writeLog('Error: cannot create order. Order code - ' . $newOrderName . ', order id - ' . $data['id'] .', data: ' . print_r($createData, true));
        $this->_item_error_code = 0; // failed to send        
        return 0;
      }
    
      $this->writeLog('New odoo order created with ID ' . $newOrderId . ' and code - ' . $newOrderName, 'info');      
   
      $lineItems = isset($data['line_items']) && is_array($data['line_items']) ? $data['line_items'] : array();                
      if (!empty($lineItems)){
    
        foreach($lineItems as $item){
        
          $sku = isset($item['sku']) ? trim($item['sku']) : '';
          $productName = isset($item['name']) ? $item['name'] : '';          
          $productPrice = isset($item['price']) ? (float) $item['price'] : 0.0;
          $unitPrice = $productPrice;
          
          if (is_a($item, 'WC_Order_Item_Product')){
            $sku = $item->get_product()->get_sku();
            $productName = $item->get_product()->get_name();
            $productPrice = $item->get_product()->get_price();
            
            $unitPrice = $item->get_order()->get_item_subtotal($item, false, true);
                       
            $item = $item->get_data();
          }                 
       
          if (empty($sku)){
            $sku = 'imported_product_' . (isset($item['product_id']) ? $item['product_id'] : ''); 
          }
        
          $productId = 0;
          
          sleep(1);
          $ids = $this->_erp->search('product.product', array(array('default_code', '=', $sku)), 0, 1);    
          if (count($ids) != 0){
            $productId = (int) $ids[0];
                  
            $this->writeLog('Found product with ID - ' . $productId . ' for sku - ' . $sku, 'info');

          } else {
            $createData = array(
                  'name' => $productName,
                  'default_code' => $sku, 
                  'list_price' => $productPrice, 
                  'type' => 'service'
                );
                
            $this->writeLog('DATA 8. create product.product : ' . print_r($createData, true), 'data');
            $this->writeLog('  ', 'data'); 
                 
            sleep(1);
            $productId = $this->_erp->create('product.product', $createData);
          
            if (!empty($productId)){
              $this->writeLog('A new product created with ID - ' . $productId . ' and sku - ' . $sku, 'info');
            } else {
              $this->writeLog('Error: cannot create product for order. Order id - ' . $data['id'] .'. Product SKU - '  . $sku . ' , data: ' . print_r($createData, true));
            }       
          }        
  
          if (empty($productId)){
            $this->writeLog('Error: cannot create order line without product. Order id - ' . $data['id'] . '. Product SKU - '  . $sku);
            $this->_item_error_code = 0; // failed to send                    
            return 0;
          }
    
          $createData = array(
              'order_id' => $newOrderId,
              'name' => $productName,
              'product_id' => $productId,
              'product_uom_qty' => isset($item['quantity']) ? (int) $item['quantity'] : 1,
              'price_unit' => $unitPrice
          );        

          $this->writeLog('DATA 9. create sale.order.line : ' . print_r($createData, true), 'data');
          $this->writeLog('  ', 'data');
          
          sleep(1);         
          $newOrderLineId = $this->_erp->create('sale.order.line', $createData);
        
          if (!empty($newOrderLineId)){
            $this->writeLog('A new order line was added to the order. Product SKU - '  . $sku, 'info');        
          }
                
        }                
      } 
       
    } catch (Exception $e) {
      
      $this->writeLog('Error cannot send order id - ' . $data['id'] . ', number - ' . $data['number']);    
      $this->writeLog('Error message: ' . $e->getMessage());
      $this->writeLog('  ');      
      $this->writeLog('ErrorTrace: ' . $e->getTraceAsString());
              
      if ($e->getCode() == $this->_connectionErrorCode){ 
        $this->_connectionError = true; 
      }
    } 
  
    return $newOrderId;
	}


	public function writeLog($message, $type = 'error'){
		  
	  if ($this->_debug_display){
	    echo htmlspecialchars($message) . '<br/>';
	  }
	  	  
	  if ($this->_write_to_log_file && $type == 'error'){
	    error_log(date('Y-m-d H:i:s', time()) . ' - ' . $message . "\r\n", 3, Pektsekye_NO()->getPluginPath() . self::LOG_FILE);
	  }	  	  
	}
    
    
  public function downloadLogFile(){
    
    $file = Pektsekye_NO()->getPluginPath() . self::LOG_FILE;
    
    if (file_exists($file)){
      
      $downloadName = 'notify_odoo_log_' . time() . '.txt';
        
      header('Content-Description: File Transfer');
      header('Content-Disposition: attachment; filename="' . $downloadName . '"');
      header('Expires: 0');
      header('Cache-Control: must-revalidate');
      header('Pragma: public');
      header('Content-Length: ' . filesize($file));
      header("Content-Type: text/plain");
      readfile($file);
      exit();
    }    
    
  }
  

  public function clearLogFile(){
    $file = Pektsekye_NO()->getPluginPath() . self::LOG_FILE;
    if (file_exists($file)){
      @file_put_contents($file, '');
    }
  }	
  
}  