<?php

error_reporting(0);
ini_set('display_errors', 0);

if (!isset($_GET['action']))
  exit;
  
define('SHORTINIT', true);

require '../../../wp-load.php';

if ($_GET['action'] == 'pcd_selector_get_product_tags'){

  $categoryId = isset($_GET['cid']) ? (int) $_GET['cid'] : 0;
  
  require_once( ABSPATH . WPINC . '/link-template.php' );    
  require_once( ABSPATH . WPINC . '/rewrite.php' );
  require_once( ABSPATH . WPINC . '/class-wp-rewrite.php');
  require_once( ABSPATH . WPINC . '/post.php' );
  require_once( ABSPATH . WPINC . '/l10n.php' );
  require_once( ABSPATH . WPINC . '/class-wp-post.php' );   
  require_once( ABSPATH . WPINC . '/class-wp-post-type.php' );  

  $GLOBALS['wp_rewrite'] = new WP_Rewrite();

  register_post_type(
    'product',
      array(
        'rewrite' => array(
          'slug'       => 'product',
          'with_front' => false,
          'feeds'      => true,
        ) 
      )			
  );

  $select = "
   SELECT DISTINCT terms2.slug, terms2.name
    FROM
        wp_posts as p1
        LEFT JOIN {$wpdb->term_relationships} as r1 ON p1.ID = r1.object_ID
        LEFT JOIN {$wpdb->term_taxonomy} as t1 ON r1.term_taxonomy_id = t1.term_taxonomy_id
        LEFT JOIN {$wpdb->terms} as terms1 ON t1.term_id = terms1.term_id,

        wp_posts as p2
        LEFT JOIN {$wpdb->term_relationships} as r2 ON p2.ID = r2.object_ID
        LEFT JOIN {$wpdb->term_taxonomy} as t2 ON r2.term_taxonomy_id = t2.term_taxonomy_id
        LEFT JOIN {$wpdb->terms} as terms2 ON t2.term_id = terms2.term_id
    WHERE
        t1.taxonomy = 'product_cat' AND p1.post_status = 'publish' AND terms1.term_id = {$categoryId} AND
        t2.taxonomy = 'product_tag' AND p2.post_status = 'publish'
        AND p1.ID = p2.ID
    ORDER by terms2.name    
  ";  
             
  $result = (array) $wpdb->get_results($select, ARRAY_A);
  
  $tags = array();
  foreach ($result as $row){
    $tags[] = array('slug' => $row['slug'], 'name' => $row['name']);    
  }
                        
  echo json_encode(array('productTags' => $tags));
  exit;   
  
}
